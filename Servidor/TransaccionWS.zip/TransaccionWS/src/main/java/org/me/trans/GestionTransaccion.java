/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package org.me.trans;

import estructura.Pagar;
import estructura.VerificaPago;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author yesen
 */
@WebService(serviceName = "GestionTransaccion")
public class GestionTransaccion {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "Validar")
    public Pagar Validar(@WebParam(name = "numeroTarjeta") int numeroTarjeta, @WebParam(name = "monto") int monto, @WebParam(name = "nombre") String nombre, @WebParam(name = "codigo_CVV") int codigo_CVV) {
        VerificaPago vp = new VerificaPago();
        Pagar pagar = vp.verificaP(numeroTarjeta, monto,nombre,codigo_CVV);
        return pagar;
    }
    

    /**
     * Web service operation
     * int numeroTarjeta, int monto, String nombre, int codigo_CVV
     */
    @WebMethod(operationName = "Registrar")
    public String Registrar(@WebParam(name = "numeroTarjeta") int numeroTarjeta, @WebParam(name = "monto") int monto, @WebParam(name = "nombre") String nombre, @WebParam(name = "codigo_CVV") int codigo_CVV) {
        VerificaPago vp = new VerificaPago();
        String respuesta = vp.registraPago(numeroTarjeta, monto,nombre,codigo_CVV);
        return respuesta;
    }
}
