/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructura;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author yesen
 */
public class VerificaCompra {
     Conexion conexion;

    public VerificaCompra() {
        conexion = new Conexion();
    }


    public Pagar verificaC(int idProducto, boolean precio, int numero_productos, boolean total){
        Pagar pagar=null;
        Connection accesoDB = conexion.getConexion();
        try {
            
            PreparedStatement ps = accesoDB.prepareStatement("select * from pagar where numeroTarjeta=? and monto=? and nombre=? and codigo_CVV=?");
            ps.setInt(1, idProducto);
            ps.setInt(2, numero_productos);
            ps.setInt(3, total);
            
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
               pagar = new Pagar();
               pagar.setNumeroTarjeta(rs.getInt(1));
               pagar.setMonto(rs.getInt(2));
               pagar.setNombre(rs.getString(3));
               pagar.setCodigo_CVV(rs.getInt(4));
               
               return pagar;
            }
        } catch (Exception e) {
        }
        return pagar;
    }
    
    public String registraCompra(int numeroTarjeta, int monto,String nombre,int codigo_CVV){
        String respuesta=null;
        Connection accesoDB = conexion.getConexion();
        try {
            PreparedStatement ps = accesoDB.prepareStatement("insert into empleado(numeroTarjeta, monto,nombre,codigo_CVV) values (?,?,?,?,?)");
            ps.setInt(1, numeroTarjeta);
            ps.setInt(2, monto);
            ps.setString(3, nombre);
            ps.setInt(4, codigo_CVV);
     
            int rs = ps.executeUpdate();
            
            if(rs>0){
                respuesta="Registro exitoso.";
            }
        } catch (Exception e) {
        }
        return respuesta;
    }
}
