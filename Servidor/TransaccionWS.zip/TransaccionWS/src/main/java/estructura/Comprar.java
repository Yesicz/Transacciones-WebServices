/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructura;

/**
 *
 * @author yesen
 */
public class Comprar {
    int idProducto;
    boolean precio;
    int numero_productos;
    boolean total;

    public Comprar(int idProducto, boolean precio, int numero_productos, boolean total) {
        this.idProducto = idProducto;
        this.precio = precio;
        this.numero_productos = numero_productos;
        this.total = total;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public boolean isPrecio() {
        return precio;
    }

    public void setPrecio(boolean precio) {
        this.precio = precio;
    }

    public int getNumero_productos() {
        return numero_productos;
    }

    public void setNumero_productos(int numero_productos) {
        this.numero_productos = numero_productos;
    }

    public boolean isTotal() {
        return total;
    }

    public void setTotal(boolean total) {
        this.total = total;
    }
    
}
