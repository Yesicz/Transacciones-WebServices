/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructura;

/**
 *
 * @author yesen
 */
public class Pagar {
    int numeroTarjeta;
    int monto;
    String nombre;
    int codigo_CVV;
    
    
    public Pagar() {
    }
    
    public Pagar(int numeroTarjeta, int monto, String nombre, int codigo_CVV) {
        this.numeroTarjeta = numeroTarjeta;
        this.monto = monto;
        this.nombre = nombre;
        this.codigo_CVV = codigo_CVV;
    }

    public int getNumeroTarjeta() {
        return numeroTarjeta;
    }

    public void setNumeroTarjeta(int numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }

    public int getMonto() {
        return monto;
    }

    public void setMonto(int monto) {
        this.monto = monto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCodigo_CVV() {
        return codigo_CVV;
    }

    public void setCodigo_CVV(int codigo_CVV) {
        this.codigo_CVV = codigo_CVV;
    }

    

}
